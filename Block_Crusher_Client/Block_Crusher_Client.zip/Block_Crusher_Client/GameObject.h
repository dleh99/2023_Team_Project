#pragma once

#include "Mesh.h"
#include "Camera.h"

class CGameObject
{
protected:
	UINT m_nMesh = 0;
	CMesh* m_MeshList = NULL;

	XMFLOAT4X4 m_xmf4x4World;
	XMFLOAT3 m_xmf3Color = XMFLOAT3(1.0f, 1.0f, 1.0f);

public:
	CGameObject();

	int LoadMeshFromFile(string);
	void SetMeshesDataToResource(ID3D12Device*, ID3D12GraphicsCommandList*, const char*);

	virtual void UpdateShaderVariables(ID3D12GraphicsCommandList*);
	virtual void OnPrepareRender() { }
	virtual void Render(ID3D12GraphicsCommandList*, CCamera* = NULL);
};

