#pragma once

class CPlayer;

class CCamera
{
protected:
	XMFLOAT3 m_playerPosition;
	XMFLOAT3 m_playerRight;
	XMFLOAT3 m_playerUp;
	XMFLOAT3 m_playerLook;

	float m_playerPitch;
	float m_playerRoll;
	float m_playerYaw;

	CPlayer* m_player = NULL;

public:
	virtual void Move(const XMFLOAT3& shift)
	{ m_playerPosition.x += shift.x; m_playerPosition.y += shift.y; m_playerPosition.z += shift.z; }
};

