#include "stdafx.h"
#include "GameObject.h"

CGameObject::CGameObject()
{
	m_xmf4x4World = Matrix4x4::Identity();
}

int CGameObject::LoadMeshFromFile(string fileName)
{
	ifstream in{ fileName,ios::binary };
	if (!in) {
		cout << "Mesh ���� ���� �ε� ����" << endl;
		return -1;
	}

	int nMesh;
	in.read(reinterpret_cast<char*>(&nMesh), sizeof(nMesh));		// read Mesh number

	m_MeshList = new CMesh[nMesh];

	for (int i = 0; i < nMesh; ++i) {
		m_MeshList[i].LoadMeshFromFile(in);
	}

	/*for (int i = 0; i < nMesh; ++i) {
		m_MeshList[i].PrintMeshInformation();
	}*/

	return 0;
}

void CGameObject::SetMeshesDataToResource(ID3D12Device* d3dDevice, ID3D12GraphicsCommandList* d3dCommandList, const char* strFileName)
{
	for (UINT i = 0; i < m_nMesh; ++i) {
		m_MeshList[i].SetMeshDataToResource(d3dDevice, d3dCommandList, strFileName);
	}
}

void CGameObject::UpdateShaderVariables(ID3D12GraphicsCommandList* d3dCommandList)
{
	XMFLOAT4X4 xmf4x4World;
	XMStoreFloat4x4(&xmf4x4World, XMMatrixTranspose(XMLoadFloat4x4(&m_xmf4x4World)));
	d3dCommandList->SetGraphicsRoot32BitConstants(1, 16, &xmf4x4World, 0);

	d3dCommandList->SetGraphicsRoot32BitConstants(1, 3, &m_xmf3Color, 16);
}

void CGameObject::Render(ID3D12GraphicsCommandList* d3dCommandList, CCamera* camera)
{
	OnPrepareRender();
	//if (m_Shader) m_Shader->Render(d3dCommandList, camera);
	
	UpdateShaderVariables(d3dCommandList);
	
	if (m_MeshList) {
		for (UINT i = 0; i < m_nMesh; ++i) {
			m_MeshList[i].Render(d3dCommandList);
		}
	}
}
