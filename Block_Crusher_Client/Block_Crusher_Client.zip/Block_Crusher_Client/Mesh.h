#pragma once

class CMesh
{
public:
	~CMesh();

protected:
	UINT m_nVertex = 0;

	XMFLOAT3* m_positionList = NULL;
	ID3D12Resource* m_d3dPositionBuffer = NULL;
	ID3D12Resource* m_d3dPositionUploadBuffer = NULL;

	XMFLOAT3* m_normalList = NULL;
	ID3D12Resource* m_d3dNormalBuffer = NULL;
	ID3D12Resource* m_d3dNormalUploadBuffer = NULL;

	XMFLOAT3* m_tangentList = NULL;
	ID3D12Resource* m_d3dTangentBuffer = NULL;
	ID3D12Resource* m_d3dTangentUploadBuffer = NULL;

	XMFLOAT2* m_textureCoordList = NULL;
	ID3D12Resource* m_d3dTextureCoordBuffer = NULL;
	ID3D12Resource* m_d3dTextureCoordUploadBuffer = NULL;

	UINT m_nVertexBufferViews = 0;
	D3D12_VERTEX_BUFFER_VIEW* m_d3dVertexBufferViews = NULL;

	D3D12_INDEX_BUFFER_VIEW m_d3dIndexBufferView;

	ID3D12Resource* m_d3dIndexBuffer = NULL;
	ID3D12Resource* m_d3dIndexUploadBuffer = NULL;

	D3D12_PRIMITIVE_TOPOLOGY m_d3dPrimitiveTopology = D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
	UINT m_nSlot = 0;
	UINT m_nStride = 0;
	UINT m_nOffset = 0;

public:
	int LoadMeshFromFile(ifstream&);
	void SetMeshDataToResource(ID3D12Device*, ID3D12GraphicsCommandList*, const char*);
	void PrintMeshInformation();

	virtual void Render(ID3D12GraphicsCommandList*);
};