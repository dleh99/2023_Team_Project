#pragma once

#include "Camera.h"

class CShader
{
};

