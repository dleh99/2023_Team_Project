#include "stdafx.h"
#include "Player.h"

CPlayer::CPlayer()
{
	m_Camera = NULL;

	m_playerPosition = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_playerRight = XMFLOAT3(1.0f, 0.0f, 0.0f);
	m_playerUp = XMFLOAT3(0.0f, 1.0f, 0.0f);
	m_playerLook = XMFLOAT3(0.0f, 0.0f, 1.0f);

	m_playerPitch = 0.0f;
	m_playerRoll = 0.0f;
	m_playerYaw = 0.0f;

	m_playerVelocity = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_playerGravity = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_playerMaxVelocityXZ = 0.0f;
	m_playerMaxVelocityY = 0.0f;
	m_playerFriction = 0.0f;

	m_playerUpdatedContext = NULL;
	m_cameraUpdatedContext = NULL;
}

CPlayer::CPlayer(ID3D12Device* d3dDevice, ID3D12GraphicsCommandList* d3dCommandList,
	ID3D12RootSignature* d3dGraphicsRootSignature)
{
	/*m_Camera = ChangeCamera(THIRD_PERSON_CAMERA, 0.0f);

	SetPosition(XMFLOAT3(-3.944041f, 7.696952f, -2.04254f));

	SetColor(XMFLOAT3(0.0f, 0.25f, 0.875f));*/

	m_playerRight = XMFLOAT3(1.0f, 0.0f, 0.0f);
	m_playerUp = XMFLOAT3(0.0f, 1.0f, 0.0f);
	m_playerLook = XMFLOAT3(0.0f, 0.0f, 1.0f);

	m_playerPitch = 0.0f;
	m_playerRoll = 0.0f;
	m_playerYaw = 0.0f;

	m_playerVelocity = XMFLOAT3(0.0f, 0.0f, 0.0f);

	m_playerUpdatedContext = NULL;
	m_cameraUpdatedContext = NULL;
}

CCamera* CPlayer::OnChangeCamera()
{
	CCamera* newCamera = NULL;
	/*newCamera = new CThirdPersonCamera(m_Camera);

	newCamera->SetPlayer(this);*/

	return newCamera;
}

void CPlayer::Move(const XMFLOAT3& shift, bool updateVelocity)
{
	if (updateVelocity)
	{
		m_playerVelocity = Vector3::Add(m_playerVelocity, shift);
	}
	else
	{
		m_playerPosition = Vector3::Add(m_playerPosition, shift);
		m_Camera->Move(shift);
	}
}

void CPlayer::OnPrepareRender()
{
	m_xmf4x4World._11 = m_playerRight.x; m_xmf4x4World._12 = m_playerRight.y; m_xmf4x4World._13 = m_playerRight.z;
	m_xmf4x4World._21 = m_playerUp.x; m_xmf4x4World._22 = m_playerUp.y; m_xmf4x4World._23 = m_playerUp.z;
	m_xmf4x4World._31 = m_playerLook.x; m_xmf4x4World._32 = m_playerLook.y; m_xmf4x4World._33 = m_playerLook.z;
	m_xmf4x4World._41 = m_playerPosition.x; m_xmf4x4World._42 = m_playerPosition.y; m_xmf4x4World._43 = m_playerPosition.z;
}

void CPlayer::Render(ID3D12GraphicsCommandList* d3dCommandList, CCamera* camera)
{
	CGameObject::Render(d3dCommandList, camera);
}
