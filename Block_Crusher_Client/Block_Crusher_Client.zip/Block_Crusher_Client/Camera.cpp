#include "stdafx.h"
#include "Camera.h"
