#pragma once

#include "Player.h"
#include "Scene.h"

class CGameFramework
{
private:
	HINSTANCE m_hInstance;
	HWND m_hWindow;

	int m_nWindowClientWidth;
	int m_nWindowClientHeight;

	IDXGIFactory4* m_dxgiFactory;
	IDXGISwapChain3* m_dxgiSwapChain;
	ID3D12Device* m_d3dDevice;

	static const UINT m_nSwapChainBuffers = 2;
	UINT m_nSwapChainBufferIndex;
	
	ID3D12Fence* m_d3dFence;
	HANDLE m_hFenceEvent;
	UINT64 m_nFenceValues[m_nSwapChainBuffers];

	ID3D12Resource* m_d3dSwapChainBackBuffers[m_nSwapChainBuffers];
	ID3D12DescriptorHeap* m_d3dRtvDescriptorHeap;
	UINT m_nRtvDescriptorIncrementSize;

	ID3D12Resource* m_d3dDepthStencilBuffer;
	ID3D12DescriptorHeap* m_d3dDsvDescriptorHeap;
	UINT m_nDsvDescriptorIncrementSize;

	ID3D12CommandAllocator* m_d3dCommandAllocator;
	ID3D12CommandQueue* m_d3dCommandQueue;
	ID3D12GraphicsCommandList* m_d3dCommandList;

	CPlayer* m_Player = NULL;
	CCamera* m_Camera = NULL;
	CScene* m_Scene = NULL;

public:
	CGameFramework();

	void FrameAdvance();
	void BuildObjects();

	bool OnCrearte(HINSTANCE hInstance, HWND hMainWindow);
	
	void CreateDirect3DDevice();
	void CreateCommandQueueAndList();
	void CreateRtvAndDsvDescriptorHeaps();
	void CreateSwapChain();
	void CreateRenderTargetViews();
	void CreateDepthStencilView();

	void WaitForGpuComplete();
	void MoveToNextFrame();
};

