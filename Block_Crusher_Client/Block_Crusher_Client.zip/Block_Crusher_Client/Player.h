#pragma once

#include "GameObject.h"
#include "Camera.h"

class CPlayer : public CGameObject
{
protected:
	XMFLOAT3					m_playerPosition;
	XMFLOAT3					m_playerRight;
	XMFLOAT3					m_playerUp;
	XMFLOAT3					m_playerLook;

	float           			m_playerPitch;
	float           			m_playerYaw;
	float           			m_playerRoll;

	XMFLOAT3					m_playerVelocity;
	XMFLOAT3     				m_playerGravity;
	float           			m_playerMaxVelocityXZ;
	float           			m_playerMaxVelocityY;
	float           			m_playerFriction;

	LPVOID						m_playerUpdatedContext;
	LPVOID						m_cameraUpdatedContext;

	CCamera* m_Camera = NULL;

public:
	CPlayer();
	CPlayer(ID3D12Device*, ID3D12GraphicsCommandList*, ID3D12RootSignature*);

	CCamera* OnChangeCamera();

	void SetFriction(float fFriction) { m_playerFriction = fFriction; }
	void SetGravity(const XMFLOAT3& xmf3Gravity) { m_playerGravity = xmf3Gravity; }
	void SetMaxVelocityXZ(float fMaxVelocity) { m_playerMaxVelocityXZ = fMaxVelocity; }
	void SetMaxVelocityY(float fMaxVelocity) { m_playerMaxVelocityY = fMaxVelocity; }
	void SetVelocity(const XMFLOAT3& xmf3Velocity) { m_playerVelocity = xmf3Velocity; }
	void SetPosition(const XMFLOAT3& xmf3Position) { Move(XMFLOAT3(xmf3Position.x - m_playerPosition.x,
		xmf3Position.y - m_playerPosition.y, xmf3Position.z - m_playerPosition.z), false); }

	void Move(const XMFLOAT3&, bool = false);

	CCamera* GetCamera() { return(m_Camera); }



	virtual void OnPrepareRender();
	virtual void Render(ID3D12GraphicsCommandList*, CCamera* = NULL);
};

