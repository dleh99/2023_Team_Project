#pragma once

#include "Shader.h"

class CScene
{
protected:
	ID3D12RootSignature* m_d3dGraphicsRootSignature = NULL;

public:
	void BuildObjects(ID3D12Device*, ID3D12GraphicsCommandList*);

	ID3D12RootSignature* CreateGraphicsRootSignature(ID3D12Device*);
	ID3D12RootSignature* GetGraphicsRootSignature() { return(m_d3dGraphicsRootSignature); }
};

