#include "stdafx.h"
#include "Mesh.h"

CMesh::~CMesh()
{
	delete[] m_positionList;
	delete[] m_normalList;
	delete[] m_tangentList;
	delete[] m_textureCoordList;
}

int CMesh::LoadMeshFromFile(ifstream& in)
{
	in.read(reinterpret_cast<char*>(&m_nVertex), sizeof(m_nVertex));	// read vertex number
	m_positionList = new XMFLOAT3[m_nVertex];

	for (UINT i = 0; i < m_nVertex; ++i) {								// read vertex
		in.read(reinterpret_cast<char*>(&m_positionList[i]), sizeof(XMFLOAT3));
	}

	in.read(reinterpret_cast<char*>(&m_nVertex), sizeof(m_nVertex));
	m_normalList = new XMFLOAT3[m_nVertex];

	for (UINT i = 0; i < m_nVertex; ++i) {								// read normal
		in.read(reinterpret_cast<char*>(&m_normalList[i]), sizeof(XMFLOAT3));
	}

	in.read(reinterpret_cast<char*>(&m_nVertex), sizeof(m_nVertex));
	m_tangentList = new XMFLOAT3[m_nVertex];

	for (UINT i = 0; i < m_nVertex; ++i) {								// read tangent
		in.read(reinterpret_cast<char*>(&m_tangentList[i]), sizeof(XMFLOAT3));
	}

	in.read(reinterpret_cast<char*>(&m_nVertex), sizeof(m_nVertex));
	m_textureCoordList = new XMFLOAT2[m_nVertex];

	for (UINT i = 0; i < m_nVertex; ++i) {								// read UV0
		in.read(reinterpret_cast<char*>(&m_textureCoordList[i]), sizeof(XMFLOAT2));
	}

	return 0;
}

void CMesh::SetMeshDataToResource(ID3D12Device* d3dDevice, ID3D12GraphicsCommandList* d3dCommandList, const char* strFileName)
{
	m_d3dPositionBuffer = ::CreateBufferResource(d3dDevice, d3dCommandList, m_positionList, sizeof(XMFLOAT3) * m_nVertex, D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER, &m_d3dPositionUploadBuffer);
	m_d3dNormalBuffer = ::CreateBufferResource(d3dDevice, d3dCommandList, m_normalList, sizeof(XMFLOAT3) * m_nVertex, D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER, &m_d3dNormalUploadBuffer);
	m_d3dTextureCoordBuffer = ::CreateBufferResource(d3dDevice, d3dCommandList, m_textureCoordList, sizeof(XMFLOAT2) * m_nVertex, D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER, &m_d3dTextureCoordUploadBuffer);

	m_nVertexBufferViews = 3;
	m_d3dVertexBufferViews = new D3D12_VERTEX_BUFFER_VIEW[m_nVertexBufferViews];

	m_d3dVertexBufferViews[0].BufferLocation = m_d3dPositionBuffer->GetGPUVirtualAddress();
	m_d3dVertexBufferViews[0].StrideInBytes = sizeof(XMFLOAT3);
	m_d3dVertexBufferViews[0].SizeInBytes = sizeof(XMFLOAT3) * m_nVertex;

	m_d3dVertexBufferViews[1].BufferLocation = m_d3dPositionBuffer->GetGPUVirtualAddress();
	m_d3dVertexBufferViews[1].StrideInBytes = sizeof(XMFLOAT3);
	m_d3dVertexBufferViews[1].SizeInBytes = sizeof(XMFLOAT3) * m_nVertex;

	m_d3dVertexBufferViews[2].BufferLocation = m_d3dPositionBuffer->GetGPUVirtualAddress();
	m_d3dVertexBufferViews[2].StrideInBytes = sizeof(XMFLOAT2);
	m_d3dVertexBufferViews[2].SizeInBytes = sizeof(XMFLOAT2) * m_nVertex;

	int index{};
	int* pIndex = &index;
	m_d3dIndexBuffer = ::CreateBufferResource(d3dDevice, d3dCommandList, pIndex, sizeof(UINT) * index, D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_INDEX_BUFFER, &m_d3dIndexUploadBuffer);

	m_d3dIndexBufferView.BufferLocation = m_d3dIndexBuffer->GetGPUVirtualAddress();
	m_d3dIndexBufferView.Format = DXGI_FORMAT_R32_UINT;
	m_d3dIndexBufferView.SizeInBytes = sizeof(UINT) * index;
}

void CMesh::PrintMeshInformation()
{
	for (UINT i = 0; i < m_nVertex; ++i) {
		cout << "( "
			<< m_positionList[i].x << ", "
			<< m_positionList[i].y << ", "
			<< m_positionList[i].z << " )" << endl;
	}

	for (UINT i = 0; i < m_nVertex; ++i) {
		cout << "( "
			<< m_normalList[i].x << ", "
			<< m_normalList[i].y << ", "
			<< m_normalList[i].z << " )" << endl;
	}

	for (UINT i = 0; i < m_nVertex; ++i) {
		cout << "( "
			<< m_tangentList[i].x << ", "
			<< m_tangentList[i].y << ", "
			<< m_tangentList[i].z << " )" << endl;
	}

	for (UINT i = 0; i < m_nVertex; ++i) {
		cout << "( "
			<< m_textureCoordList[i].x << ", "
			<< m_textureCoordList[i].y << " )" << endl;
	}
}

void CMesh::Render(ID3D12GraphicsCommandList* pd3dCommandList)
{
	pd3dCommandList->IASetPrimitiveTopology(m_d3dPrimitiveTopology);
	pd3dCommandList->IASetVertexBuffers(m_nSlot, m_nVertexBufferViews, m_d3dVertexBufferViews);
	if (m_d3dIndexBuffer)
	{
		pd3dCommandList->IASetIndexBuffer(&m_d3dIndexBufferView);
		pd3dCommandList->DrawIndexedInstanced(0, 1, 0, 0, 0);
		cout << "Indexed Draw Call ȣ��" << endl;
	}
	else
	{
		pd3dCommandList->DrawInstanced(m_nVertex, 1, m_nOffset, 0);
		cout << "Draw Call ȣ��" << endl;
	}
}
